def cartoonifier(imagepath):
    import matplotlib
    from mpl_toolkits import mplot3d
    from matplotlib import pyplot as plt
    from matplotlib import cm
    from matplotlib import image as mpimg
    from matplotlib.pyplot import figure
    import cv2
    # %matplotlib inline
    
    #TO DO
    #step 1
    #Use bilateral filter for edge-aware smoothing.

    img= cv2.imread(imagepath)
    rows=img.shape[0]
    col=img.shape[1]
    img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
    num_down = 4 # number of downsampling steps 
    num_bilateral =4  # number of bilateral filtering steps
    for i in range(num_down):
        img = cv2.pyrDown(img)        
    for i in range(num_bilateral):
        img = cv2.bilateralFilter(img,10,10,6)
    for i in range(num_down):
        img = cv2.pyrUp(img)
    img=img[0:rows,0:col]
  
  
  
    gray= cv2.imread(imagepath)
    gray=cv2.cvtColor(gray,cv2.COLOR_BGR2GRAY)
    gray=cv2.medianBlur(gray,9)
    # plt.imshow(gray,cmap='gray')

    # In[209]:


    #TO DO
    adpthres = cv2.adaptiveThreshold(gray,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C,cv2.THRESH_BINARY,15,2)
    # plt.imshow(adpthres,cmap='gray')
    backimg=cv2.cvtColor(adpthres,cv2.COLOR_GRAY2RGB)

    dest_and = img&backimg
    final=dest_and
    # plt.imshow(dest_and)
    return final

def blackwhite(imagepath):
    import matplotlib
    from mpl_toolkits import mplot3d
    from matplotlib import pyplot as plt
    from matplotlib import cm
    from matplotlib import image as mpimg
    from matplotlib.pyplot import figure
    import cv2
  
  
    gray= cv2.imread(imagepath)
    gray=cv2.cvtColor(gray,cv2.COLOR_BGR2GRAY)
    # gray=cv2.medianBlur(gray,9)
    final=gray
    return final
